import argparse
import subprocess as sp
import statistics
import plotly.graph_objects as go
import plotly.io as iom
import pandas as pd
import json
import time
import os
import sys
import glob

parser = argparse.ArgumentParser(description="""Run traceroute multiple 
times towards a given target host""")
parser.add_argument('-n', dest='NUM_RUNS', type=int, default=1,
                    help='Number of times traceroute will run')
parser.add_argument('-d', dest='RUN_DELAY', default=1, type=int,
                    help='Number of seconds to wait between two consecutive runs')
parser.add_argument('-m', dest='MAX_HOPS', type=int, default=30,
                    help='Number of times traceroute will run')
parser.add_argument('--test', dest='TEST_DIR',
                    help="""Directory containing num_runs text files, each of which
                   contains the output of a traceroute run.If present, this
                   will override all other options and tcpdump will not be
                   invoked. Stats will be computed over the traceroute output
                   stored in the text files""")
parser.add_argument('-o', dest='OUTPUT', 
                    help='Path and name of output JSON file containing the stats ')
parser.add_argument('-g', dest='GRAPH',
                    help='Path and name of output PDF file containing stats graph')
parser.add_argument('-t', dest='TARGET',
                    help='A target domain name or IP address')
args = parser.parse_args()
no_of_runs = args.NUM_RUNS
run_delay = args.RUN_DELAY


max_hops_count = args.MAX_HOPS if "MAX_HOPS" in args else 0
if "OUTPUT" in args:
    json_path = args.OUTPUT
else:
    print("provide Output File Path")
    sys.exit(1)
if "GRAPH" in args:
    graph_path = args.GRAPH
else:
    print("provide Graph File Path")
    sys.exit(1)

output_dir=os.path.dirname(json_path)
if output_dir:
    if not os.path.isdir(output_dir):
        os.makedirs(output_dir)

graph_dir=os.path.dirname(graph_path)
if graph_dir:
    if not os.path.isdir(graph_dir):
        os.makedirs(graph_dir)

if "TARGET" in args:
    target = args.TARGET
elif "TEST_DIR" not in args:
    print("provide TARGET for tracerooute command or TEST_DIR")
    sys.exit(1)
test_files_dir = args.TEST_DIR if "TEST_DIR" in args else None
json_data = []
ip_full_list = [[]]
hop_time_list = [[]]
cmd=["traceroute", target]
if max_hops_count:
    cmd.extend(["-m", str(max_hops_count)])
def run_command(test_files_dir, no_of_runs):
    output_list = []
    if test_files_dir:
        list_files = glob.glob(os.path.join(test_files_dir, "*.out"))
        no_of_runs = len(list_files)
        for i in range(no_of_runs):
            with open(list_files[i], "r") as fd:
                data = fd.readlines()
            output_list.append(data)
    else:
        for k in range(no_of_runs):
            with sp.Popen(cmd, stdout=sp.PIPE, stderr=sp.PIPE) as proc:
                stdout = proc.communicate()[0]
                data=stdout.decode("utf-8").split("\n")
            output_list.append(data)
    return output_list, no_of_runs
output_list, no_of_runs = run_command(test_files_dir, no_of_runs)
for data in output_list:
    for i in range(1, len(data)):
        x= data[i].split()
        index_list = []
        ip_list = []
        for j in range(len(x)):
            if x[j] == 'ms':
                index_list.append(float(x[j-1]))
                if len(index_list) == 1:
                    ip_list.append((x[j-3], x[j-2]))
                elif x[j-2] not in ["ms", "*"]:
                    ip_list.append((x[j-3], x[j-2]))
        if ip_full_list and len(ip_full_list)-1 >= i:
            if ip_list:
                for l in ip_list:
                    if l not in ip_full_list[i]:
                        ip_full_list[i].append(l)
            hop_time_list[i].extend(index_list)
        else:
            ip_full_list.append(ip_list)
            hop_time_list.append(index_list)
    time.sleep(run_delay)
no_of_hops = []
for i in range(1, len(hop_time_list)):
    
    if hop_time_list[i]:  
        min_x = min(hop_time_list[i])
        max_y = max(hop_time_list[i])
        mean = statistics.median(hop_time_list[i])
        avg = round(sum(hop_time_list[i])/len(hop_time_list[i]), 2)
    else:
        min_x = None
        max_y = None
        mean = None
        avg = None
    element = {'avg': avg, 'hop': i,
  'hosts': ip_full_list[i],
  'max': max_y,
  'med': mean,
  'min': min_x}
    json_data.append(element)
    no_of_hops.append("hop_"+str(i))
    
json_object = json.dumps(json_data, indent = 4)

with open(json_path, "w") as outfile:
    outfile.write(json_object)
    

df=pd.DataFrame(columns=["hops", ""])

fig=go.Figure(layout=go.Layout())
for x, y in zip(no_of_hops, hop_time_list[1:]):
    fig.add_trace(go.Box(y=y, name=x, marker_size=2, jitter=0.5))
fig.update_xaxes(showgrid=True)
fig.update_yaxes(showgrid=True)
iom.write_image(fig, graph_path, format="pdf")

