#! /usr/bin/python3
import argparse
from inspect import trace
import socket
import time
import random
import struct
from scapy.all import *
from dns import resolver, reversename

def socket_receiver():
    rsocket = socket.socket(
        family=socket.AF_INET,
        type=socket.SOCK_RAW,
        proto=socket.IPPROTO_ICMP
    )

    rsocket.settimeout(20)
    try:
        rsocket.bind(('', port))
    except socket.error as e:
        raise IOError('Unable to bind receiver socket: {}'.format(e))

    return rsocket

def socket_sender():
    ssocket = socket.socket(
        family=socket.AF_INET,
        type=socket.SOCK_RAW,
        proto=socket.IPPROTO_RAW
    )

    return ssocket

def ping():
    is_request = False
    try:
        ipaddr = socket.gethostbyname(target)
    except socket.error as e:
        raise Exception('target IP address did not resolved {} due to {}'.format(target, e))

    print('trace to {} ({}), {} hops max, TCP SYN to port {}'.format(target, ipaddr,
    max_hops, dst_port))
    for hopcount in range(1,max_hops+1):
        probes_list = ['*']*3
        addr_ip = None
        for i in range(len(probes_list)):

            start_time = time.time()
            receiver = socket_receiver()
            sender = socket_sender()
            packet = IP(dst=ipaddr,ttl=hopcount)/TCP(dport=dst_port,flags="S")
            wgl = packet / "Sending probes" 
            packet = wgl
            sender.sendto(packet.build(), (target, dst_port))
            addr = None
            try:
                data, addr = receiver.recvfrom(1024)
                end_time = time.time()
            except socket.error:
                pass
            finally:
                receiver.close()
                sender.close()
            if addr:
                timeCost = round((end_time - start_time) * 1000, 2)
                probes_list[i]=timeCost
                addr_ip = addr
                if addr[0] == ipaddr:
                    is_request = True
        
        if addr_ip:
            try:
                addr1 = reversename.from_address(addr_ip[0])
                domain_name = str(resolver.resolve(addr1,"PTR")[0]) + ' (' + addr_ip[0] +')'
            except Exception as e:
                domain_name = addr_ip[0] + ' (' + addr_ip[0] +')'
            print('{:<4}  {}  {} ms {} ms {} ms'.format(hopcount, domain_name, probes_list[0], probes_list[1], probes_list[2]))

        else:
            print('{:<4}  * * * * '.format(hopcount))

        if is_request:
            break


if __name__=='__main__':
    
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('-m', dest = 'MAX_HOPS', default=30,
                    help='Max hops to probe (default = 30)')
    parser.add_argument('-p', dest = 'DST_PORT', default=80,
                    help='TCP destination port (default = 80)')
    parser.add_argument('-t', dest = 'TARGET', 
                    help='Target domain or IP')
    args = parser.parse_args()
    dst_port = int(args.DST_PORT)
    max_hops = int(args.MAX_HOPS)
    target = args.TARGET
    port = random.choice(range(33434, 33535))
    ping()
